//
// Created by dkushn on 04.09.19.
//
#pragma once

#include <iostream>
#include <string>

using namespace std;

string ParseEvent(istream& is);

